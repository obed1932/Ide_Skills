# Checklist Maestro del Proyecto

## En curso

- [ ] tarea

## Pendiente

- [ ] tarea

## Bloqueos

- bloqueo 1
