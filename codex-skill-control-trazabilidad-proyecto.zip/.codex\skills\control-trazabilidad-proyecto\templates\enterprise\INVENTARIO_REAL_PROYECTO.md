# Inventario Real del Proyecto

## Estructura principal

- carpeta 1
- carpeta 2

## Entrypoints

- backend:
- frontend:
- workers:

## Servicios principales

- servicio 1
- servicio 2

## Scripts operativos

- script 1
- script 2

## Integraciones externas

- integracion 1
- integracion 2

## Legacy o ambiguo

- item 1
- item 2
