# Checklist Maestro del Proyecto

## En curso

- [ ] tarea

## Pendiente

- [ ] tarea

## Bloqueos

- bloqueo

## Aprobaciones requeridas

- aprobacion 1

## Verificacion de cierre

- [ ] pruebas o validaciones ejecutadas
- [ ] historial actualizado
- [ ] bitacora IA actualizada
- [ ] riesgos revisados
- [ ] deuda actualizada si aplica
