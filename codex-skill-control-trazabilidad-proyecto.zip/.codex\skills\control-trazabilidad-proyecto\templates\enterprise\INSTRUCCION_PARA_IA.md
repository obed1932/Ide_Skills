# Instruccion para IA

Si trabajas en este proyecto:

1. audita primero el codigo real
2. registra cambios confirmados en historial
3. registra la sesion en bitacora IA
4. si detectas riesgo o incidente, actualiza:
   - `REGISTRO_INCIDENTES_Y_SOLUCIONES.md`
   - `RIESGOS_Y_CONTROLES.md`
5. si cambias arquitectura, actualiza:
   - `CONTROL_PROYECTO_AUDITADO.md`
   - `DECISIONES_ARQUITECTURA.md`
6. si dejas workaround o inconsistencia, actualiza:
   - `DEUDA_TECNICA_Y_NORMALIZACION.md`
