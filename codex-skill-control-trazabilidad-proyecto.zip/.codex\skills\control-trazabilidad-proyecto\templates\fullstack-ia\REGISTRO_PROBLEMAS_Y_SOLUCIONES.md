# Registro de Problemas y Soluciones

## YYYY-MM-DD - PROBLEMA_CORTO

### Problema detectado

- descripcion

### Causa

- causa confirmada o probable

### Solucion aplicada

- accion tomada

### Archivos afectados

- archivo 1
- archivo 2

### Validacion

- evidencia de correccion

### Nota de seguimiento

- pendiente o riesgo residual
