---
name: control-trazabilidad-proyecto
description: Instala y mantiene un paquete de control documental para proyectos de software, con variantes minimal, enterprise y fullstack-ia. Usar cuando se necesite auditar un repo, fijar una fuente de verdad, crear historial de cambios, bitacora IA, deuda tecnica y archivos de seguimiento reutilizables.
---

# Control Trazabilidad Proyecto

Usa este skill cuando el usuario quiera:

- instalar un paquete de control documental en un repo
- auditar el estado real del proyecto
- crear una fuente de verdad documental
- registrar cambios, decisiones, deuda o incidencias
- dejar un kit para que otras IAs trabajen con disciplina operativa

## Flujo

1. Identifica la raiz del repo destino.
2. Elige la variante:
   - `minimal`: proyectos pequenos o personales
   - `enterprise`: equipos grandes, auditoria, riesgos, incidentes
   - `fullstack-ia`: backend, frontend, scripts, migraciones y trabajo frecuente con IA
3. Ejecuta el instalador:

```bash
python scripts/install_control_docs.py --target "RUTA_REPO" --variant fullstack-ia
```

4. Si el usuario no especifica variante:
   - usa `fullstack-ia` cuando el repo tenga backend y frontend o varias carpetas tecnicas
   - usa `enterprise` si el usuario habla de auditoria, compliance, riesgos o incidentes
   - usa `minimal` si es un repo simple o personal
5. Despues de instalar, completa primero `CONTROL_PROYECTO_AUDITADO.md`.
6. Ajusta `README.md` del repo destino para referenciar los archivos de control si el usuario quiere integracion completa.

## Portabilidad

Este skill es autosuficiente.
Las variantes viven dentro de `templates/` y el instalador usa esa carpeta por defecto.
Solo usa `--source-root` si quieres forzar una fuente externa distinta.

## Reglas

- No sobrescribas archivos existentes sin confirmacion explicita del usuario.
- Si el repo ya tiene alguno de estos archivos, compara antes de reemplazar.
- Trata el codigo real del repo como fuente principal.
- Registra solo hechos confirmados.

## Validacion minima

Despues de instalar:

- confirma que los `.md` esperados existan en el repo destino
- confirma que la variante correcta fue copiada
- informa que falta completar el control auditado inicial
