from __future__ import annotations

import argparse
import shutil
from pathlib import Path


VALID_VARIANTS = {"minimal", "enterprise", "fullstack-ia", "base"}


def copy_variant(source_dir: Path, target_dir: Path, force: bool) -> tuple[list[str], list[str]]:
    copied: list[str] = []
    skipped: list[str] = []

    for item in source_dir.iterdir():
        destination = target_dir / item.name
        if destination.exists() and not force:
            skipped.append(item.name)
            continue

        if item.is_dir():
            if destination.exists() and force:
                shutil.rmtree(destination)
            shutil.copytree(item, destination)
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, destination)
        copied.append(item.name)

    return copied, skipped


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Instala una variante del kit de control documental en un repo destino."
    )
    parser.add_argument("--target", required=True, help="Ruta del repo destino")
    parser.add_argument(
        "--variant",
        required=True,
        choices=sorted(VALID_VARIANTS),
        help="Variante a instalar",
    )
    parser.add_argument(
        "--source-root",
        default="",
        help="Ruta opcional al directorio que contiene las variantes. Si se omite, usa ./templates del skill.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Sobrescribe archivos existentes de la variante elegida",
    )
    parser.add_argument(
        "--subdir",
        default="",
        help="Subdirectorio opcional dentro del repo destino donde copiar los archivos",
    )
    args = parser.parse_args()

    script_path = Path(__file__).resolve()
    default_source_root = script_path.parents[1] / "templates"
    source_root = Path(args.source_root).resolve() if args.source_root else default_source_root
    source_dir = source_root / args.variant

    if not source_dir.exists():
        raise SystemExit(f"No existe la variante: {source_dir}")

    target_dir = Path(args.target).resolve()
    if args.subdir:
        target_dir = target_dir / args.subdir

    target_dir.mkdir(parents=True, exist_ok=True)
    copied, skipped = copy_variant(source_dir, target_dir, args.force)

    print(f"Variante instalada: {args.variant}")
    print(f"Origen: {source_dir}")
    print(f"Destino: {target_dir}")
    print(f"Copiados: {len(copied)}")
    for name in copied:
        print(f"  + {name}")

    if skipped:
        print(f"Omitidos por existir y no usar --force: {len(skipped)}")
        for name in skipped:
            print(f"  - {name}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
