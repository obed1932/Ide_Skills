# Deuda Tecnica y Normalizacion

## Resumen

- deuda principal 1
- deuda principal 2

## Por capa

### Backend

- item

### Frontend

- item

### Datos

- item

### Documentacion

- item

## Orden sugerido de saneamiento

1. paso 1
2. paso 2
3. paso 3
