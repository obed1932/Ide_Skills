# Riesgos y Controles

## Riesgos activos

### Riesgo 1

- descripcion:
- probabilidad:
- impacto:
- control actual:
- accion pendiente:

### Riesgo 2

- descripcion:
- probabilidad:
- impacto:
- control actual:
- accion pendiente:
