# Instruccion para IA

1. auditar el codigo real
2. actualizar historial y bitacora cuando haya cambios reales
3. actualizar control auditado si cambia la linea base
4. actualizar decisiones o deuda si aplica
