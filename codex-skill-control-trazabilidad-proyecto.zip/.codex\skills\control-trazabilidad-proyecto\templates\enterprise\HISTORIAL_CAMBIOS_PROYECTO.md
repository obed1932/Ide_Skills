# Historial de Cambios del Proyecto

## YYYY-MM-DD

### Cambio
- Tipo:
- Alcance:
- Responsable:
- Archivos:
- Resultado:
- Riesgo o nota:
- Evidencia de validacion:
