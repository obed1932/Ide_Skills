# Instruccion para IA

Trabaja con este orden:

1. revisar codigo real
2. revisar `CONTROL_PROYECTO_AUDITADO.md`
3. registrar cambios reales en `HISTORIAL_CAMBIOS_PROYECTO.md`
4. registrar la sesion en `BITACORA_IA.md`
5. si se resolvio un bug o incidencia, actualizar `REGISTRO_PROBLEMAS_Y_SOLUCIONES.md`
6. si cambia una capa o contrato, actualizar `MAPA_MODULOS_Y_RUTAS.md`
7. si aparece deuda o workaround, actualizar `DEUDA_TECNICA_Y_NORMALIZACION.md`
