# Control del Proyecto Auditado

Fecha de auditoria: YYYY-MM-DD
Ubicacion auditada: `RUTA_DEL_PROYECTO`

## Objetivo

Este archivo fija la linea base real del proyecto a partir del codigo presente en disco.

## Fuente de verdad actual

### Backend activo

- Entrada principal observada:
- Bootstrap o runtime:
- Flujo de migraciones:
- Base de datos por defecto:
- Configuracion observada:

### Frontend activo

- Entrada principal observada:
- Router principal observado:
- Cliente HTTP observado:
- URL API por defecto observada:

## Modulos funcionales detectados en uso

### Frontend con rutas registradas

- modulo 1
- modulo 2

### Backend con routers o endpoints activos

- `/api/...`
- `/api/...`

## Estructuras no canonicas o ambiguas

- carpeta o archivo 1
- carpeta o archivo 2

## Conclusiones operativas

- conclusion 1
- conclusion 2
