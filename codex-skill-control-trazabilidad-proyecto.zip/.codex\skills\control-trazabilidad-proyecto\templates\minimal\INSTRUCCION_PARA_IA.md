# Instruccion para IA

Trabaja con estas reglas:

1. Validar primero el codigo real.
2. Si haces un cambio confirmado, actualizar:
   - `HISTORIAL_CAMBIOS_PROYECTO.md`
   - `BITACORA_IA.md`
3. Si cambia la linea base del proyecto, actualizar:
   - `CONTROL_PROYECTO_AUDITADO.md`
4. No registrar planes no implementados como si fueran hechos.
