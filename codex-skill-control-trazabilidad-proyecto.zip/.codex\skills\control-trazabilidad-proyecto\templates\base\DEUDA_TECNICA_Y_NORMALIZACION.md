# Deuda Tecnica y Normalizacion

## Resumen

- deuda principal 1
- deuda principal 2

## Hallazgos

### Alta prioridad

- item

### Prioridad media

- item

### Prioridad baja

- item
