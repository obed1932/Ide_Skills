# Checklist Maestro del Proyecto

## En curso

- [ ] tarea

## Pendiente

- [ ] tarea

## Bloqueos

- bloqueo

## Cierre tecnico

- [ ] historial tecnico actualizado
- [ ] bitacora IA actualizada
- [ ] mapa de modulos revisado si aplica
- [ ] deuda revisada si aplica
