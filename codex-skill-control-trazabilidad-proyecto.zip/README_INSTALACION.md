## Skill portable para Codex

Este paquete instala la skill `control-trazabilidad-proyecto` como skill global de Codex.

Estructura incluida:

- `.codex/skills/control-trazabilidad-proyecto/`
- `install-global.ps1`
- `install-global.sh`

Instalacion en otra PC:

1. Descomprime este ZIP en cualquier carpeta temporal.
2. Ejecuta `install-global.ps1` en Windows o `install-global.sh` en macOS/Linux.
3. Reinicia Codex para que vuelva a cargar las skills globales.

Ruta global objetivo:

- `~/.codex/skills/control-trazabilidad-proyecto/SKILL.md`

Notas:

- Este paquete conserva la estructura completa de la skill, incluyendo `scripts/`, `templates/` y `agents/`.
- Esta ruta se basa en la estructura global usada por Codex en este entorno.
