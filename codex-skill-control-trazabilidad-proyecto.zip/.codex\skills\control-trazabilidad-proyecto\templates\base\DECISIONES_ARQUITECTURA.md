# Decisiones de Arquitectura

## YYYY-MM-DD - TITULO_CORTO

### Contexto

- problema o tension real

### Decision

- decision tomada

### Alternativas consideradas

- alternativa 1
- alternativa 2

### Impacto

- impacto tecnico
- impacto operativo
