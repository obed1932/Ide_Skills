# Decisiones de Arquitectura

## YYYY-MM-DD - TITULO_CORTO

### Contexto

- contexto

### Decision

- decision

### Impacto por capa

- backend:
- frontend:
- datos:
- operacion:

### Deuda residual

- item
