# Control del Proyecto Auditado

Fecha de auditoria: YYYY-MM-DD
Ubicacion auditada: `RUTA_DEL_PROYECTO`
Responsable:

## Objetivo

Fijar la linea base real, tecnica y operativa del proyecto.

## Arquitectura observada

### Backend

- entrypoint:
- framework:
- base de datos:
- migraciones:
- jobs/scripts:

### Frontend

- entrypoint:
- framework:
- cliente API:
- build:

### Infraestructura

- CI/CD:
- secretos/configuracion:
- despliegue:

## Modulos activos

- modulo 1
- modulo 2

## Riesgos estructurales visibles

- riesgo 1
- riesgo 2

## Componentes no canonicos

- legacy 1
- legacy 2

## Decision de control

1. codigo ejecutable actual
2. este archivo
3. `INVENTARIO_REAL_PROYECTO.md`
4. `RIESGOS_Y_CONTROLES.md`
5. `DEUDA_TECNICA_Y_NORMALIZACION.md`
