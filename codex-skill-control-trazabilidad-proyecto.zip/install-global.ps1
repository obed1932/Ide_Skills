$ErrorActionPreference = "Stop"

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $packageRoot ".codex\skills\control-trazabilidad-proyecto"
$target = Join-Path $HOME ".codex\skills\control-trazabilidad-proyecto"

New-Item -ItemType Directory -Force (Split-Path -Parent $target) | Out-Null
Copy-Item -Recurse -Force $source $target

Write-Host "Skill instalada en: $target"
Write-Host "Reinicia Codex para que detecte la skill."
