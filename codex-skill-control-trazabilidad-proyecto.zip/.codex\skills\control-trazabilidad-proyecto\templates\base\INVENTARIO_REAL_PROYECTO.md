# Inventario Real del Proyecto

## Estructura principal

- `backend/`
- `frontend/`
- `scripts/`

## Entrypoints detectados

- backend:
- frontend:
