# Decisiones de Arquitectura

## YYYY-MM-DD - TITULO_CORTO

### Contexto

- problema o tension real

### Decision tomada

- decision

### Alternativas descartadas

- opcion 1
- opcion 2

### Motivo

- razon tecnica
- razon operativa

### Impacto

- impacto en codigo
- impacto en operacion
- impacto en mantenimiento

### Riesgo residual

- riesgo
