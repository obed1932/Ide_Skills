# Paquete Fullstack IA

Usar esta variante para:

- proyectos con backend y frontend
- repos con scripts, migraciones y pruebas
- equipos que trabajan mucho con IA
- productos en evolucion continua

## Archivos incluidos

- `README.md`
- `CONTROL_PROYECTO_AUDITADO.md`
- `HISTORIAL_CAMBIOS_PROYECTO.md`
- `BITACORA_IA.md`
- `DECISIONES_ARQUITECTURA.md`
- `DEUDA_TECNICA_Y_NORMALIZACION.md`
- `CHECKLIST_MAESTRO_PROYECTO.md`
- `INVENTARIO_REAL_PROYECTO.md`
- `MAPA_MODULOS_Y_RUTAS.md`
- `REGISTRO_PROBLEMAS_Y_SOLUCIONES.md`
- `INSTRUCCION_PARA_IA.md`

## Prioridad

Trazabilidad fuerte para producto, codigo y colaboracion con IA.
