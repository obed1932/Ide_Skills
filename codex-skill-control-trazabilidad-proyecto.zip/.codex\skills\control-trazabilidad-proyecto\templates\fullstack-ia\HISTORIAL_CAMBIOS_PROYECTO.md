# Historial de Cambios del Proyecto

## YYYY-MM-DD

### Cambio
- Tipo:
- Alcance:
- Backend:
- Frontend:
- Scripts o tests:
- Resultado:
- Riesgo o nota:
