# Historial de Cambios del Proyecto

Objetivo: registrar cambios tecnicos reales del proyecto con fecha, alcance e impacto.

## YYYY-MM-DD

### Cambio
- Tipo:
- Alcance:
- Archivos:
- Resultado:
- Riesgo o nota:
