# Paquete Minimal

Usar esta variante para:

- proyectos pequenos
- prototipos
- herramientas internas simples
- repositorios personales

## Archivos incluidos

- `README.md`
- `CONTROL_PROYECTO_AUDITADO.md`
- `HISTORIAL_CAMBIOS_PROYECTO.md`
- `BITACORA_IA.md`
- `CHECKLIST_MAESTRO_PROYECTO.md`
- `INSTRUCCION_PARA_IA.md`

## Prioridad

Maxima simplicidad con trazabilidad minima obligatoria.
