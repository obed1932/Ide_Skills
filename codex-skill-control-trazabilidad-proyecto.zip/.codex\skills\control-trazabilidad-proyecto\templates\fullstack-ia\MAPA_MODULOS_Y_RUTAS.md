# Mapa de Modulos y Rutas

## Frontend

### Rutas principales

- `/`
- `/login`
- `/modulo`

### Paginas o vistas

- pagina 1
- pagina 2

## Backend

### Routers o endpoints

- `/api/auth`
- `/api/modulo`

### Servicios internos

- servicio 1
- servicio 2

## Relaciones clave

- frontend pagina X consume backend Y
- modulo Z depende de servicio W
