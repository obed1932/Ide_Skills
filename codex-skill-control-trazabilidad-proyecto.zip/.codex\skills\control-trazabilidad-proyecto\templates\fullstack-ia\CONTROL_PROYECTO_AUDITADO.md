# Control del Proyecto Auditado

Fecha de auditoria: YYYY-MM-DD
Ubicacion auditada: `RUTA_DEL_PROYECTO`

## Fuente de verdad actual

### Backend activo

- entrada principal:
- routers o modulos:
- base de datos:
- migraciones:

### Frontend activo

- entrada principal:
- router principal:
- cliente API:
- modulo layout/auth:

### Scripts y soporte

- scripts setup:
- scripts debug:
- scripts checks:
- tests:

## Modulos funcionales detectados en uso

- autenticacion
- dominio 1
- dominio 2

## Elementos legacy o ambiguos

- item 1
- item 2

## Decision de control

1. codigo ejecutable actual
2. este archivo
3. `INVENTARIO_REAL_PROYECTO.md`
4. `MAPA_MODULOS_Y_RUTAS.md`
