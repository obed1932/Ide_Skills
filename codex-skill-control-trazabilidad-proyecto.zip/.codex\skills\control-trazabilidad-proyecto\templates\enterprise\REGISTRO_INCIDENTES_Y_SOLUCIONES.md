# Registro de Incidentes y Soluciones

## YYYY-MM-DD - INCIDENTE_CORTO

### Problema

- descripcion

### Impacto

- impacto tecnico
- impacto usuario

### Causa raiz

- causa confirmada o probable

### Solucion aplicada

- accion tomada

### Archivos o componentes afectados

- archivo o modulo

### Validacion

- como se verifico

### Prevencion futura

- control propuesto
