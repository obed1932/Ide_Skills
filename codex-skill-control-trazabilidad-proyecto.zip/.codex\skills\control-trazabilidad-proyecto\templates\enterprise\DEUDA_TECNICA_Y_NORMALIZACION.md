# Deuda Tecnica y Normalizacion

## Resumen ejecutivo

- deuda 1
- deuda 2

## Deuda por categoria

### Arquitectura

- item

### Datos y migraciones

- item

### Seguridad

- item

### Observabilidad

- item

### Documentacion

- item

## Plan de normalizacion

1. fase 1
2. fase 2
3. fase 3
