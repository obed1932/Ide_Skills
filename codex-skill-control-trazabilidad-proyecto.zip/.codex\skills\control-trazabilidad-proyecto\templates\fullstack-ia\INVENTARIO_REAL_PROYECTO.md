# Inventario Real del Proyecto

## Estructura principal

- `backend/`
- `frontend/`
- `scripts/`
- `tests/`

## Entrypoints detectados

- backend:
- frontend:

## Servicios y modulos

- auth
- api
- ui
- jobs

## Artefactos auxiliares

- debug
- maintenance
- migrations
- seeds

## Legacy o ambiguo

- item 1
- item 2
