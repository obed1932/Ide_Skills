# Bitacora de Interacciones con IA

Objetivo: registrar sesiones de trabajo con IA, decisiones tomadas, archivos tocados y resultados.

## YYYY-MM-DD

### Sesion
- Objetivo:
- Trabajo realizado:
- Archivos creados o modificados:
- Decisiones tomadas:
- Riesgos detectados:
- Siguiente paso sugerido:
