# Paquete Base

Esta carpeta replica el paquete neutro original de control documental.

Archivos recomendados:

- `README.md`
- `CONTROL_PROYECTO_AUDITADO.md`
- `HISTORIAL_CAMBIOS_PROYECTO.md`
- `BITACORA_IA.md`
- `DECISIONES_ARQUITECTURA.md`
- `DEUDA_TECNICA_Y_NORMALIZACION.md`
- `CHECKLIST_MAESTRO_PROYECTO.md`
- `INVENTARIO_REAL_PROYECTO.md`
- `MEMORIA_CONTEXTUAL.md`
- `INSTRUCCION_PARA_IA.md`
