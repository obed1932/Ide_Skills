#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$PACKAGE_ROOT/.codex/skills/control-trazabilidad-proyecto"
TARGET="$HOME/.codex/skills/control-trazabilidad-proyecto"

mkdir -p "$(dirname "$TARGET")"
rm -rf "$TARGET"
cp -R "$SOURCE" "$TARGET"

echo "Skill instalada en: $TARGET"
echo "Reinicia Codex para que detecte la skill."
