# Control Trazabilidad Proyecto para Antigravity

Este proyecto contiene un kit portable de control documental para repositorios de software.

Cuando el usuario pida instalar, aplicar o inicializar control de proyecto, usa esta estructura:

- `templates/minimal`: control liviano para proyectos pequenos.
- `templates/base`: control estandar para proyectos normales.
- `templates/enterprise`: control con auditoria, riesgos e incidentes.
- `templates/fullstack-ia`: control para repos con backend, frontend, scripts, migraciones y trabajo con IA.

## Comando principal

Desde esta carpeta:

```powershell
python scripts/install_control_docs.py --target "RUTA_DEL_REPO" --variant fullstack-ia
```

Variantes validas:

```txt
minimal
base
enterprise
fullstack-ia
```

## Criterio de seleccion

- Usa `fullstack-ia` si hay backend y frontend, Docker, migraciones o trabajo frecuente con IA.
- Usa `enterprise` si el usuario menciona auditoria, riesgos, cumplimiento o incidentes.
- Usa `base` para un proyecto de tamano medio.
- Usa `minimal` para proyectos pequenos o personales.

## Reglas de trabajo

- No sobrescribas archivos existentes sin confirmacion explicita.
- Trata el codigo real del repo como fuente principal.
- Registra solo hechos confirmados.
- Despues de instalar, abre y completa primero `CONTROL_PROYECTO_AUDITADO.md`.
- Si el repo ya tiene README o historial, integra referencias sin borrar informacion existente.

