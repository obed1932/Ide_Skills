param(
    [Parameter(Mandatory=$true)]
    [string]$Target,

    [string]$Variant = "fullstack-ia"
)

$ErrorActionPreference = "Stop"

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$targetRoot = Resolve-Path -LiteralPath $Target
$agentDir = Join-Path $targetRoot ".agent"
$rulesDir = Join-Path $agentDir "rules"
$kitDir = Join-Path $agentDir "control-trazabilidad-proyecto"

New-Item -ItemType Directory -Force -Path $rulesDir | Out-Null
New-Item -ItemType Directory -Force -Path $kitDir | Out-Null

Copy-Item -LiteralPath (Join-Path $packageRoot ".agent\rules\control-trazabilidad-proyecto.md") -Destination (Join-Path $rulesDir "control-trazabilidad-proyecto.md") -Force
Copy-Item -LiteralPath (Join-Path $packageRoot "AGENTS.md") -Destination (Join-Path $kitDir "AGENTS.md") -Force
Copy-Item -LiteralPath (Join-Path $packageRoot "GEMINI.md") -Destination (Join-Path $kitDir "GEMINI.md") -Force
Copy-Item -LiteralPath (Join-Path $packageRoot "README_ANTIGRAVITY.md") -Destination (Join-Path $kitDir "README_ANTIGRAVITY.md") -Force

if (Test-Path -LiteralPath (Join-Path $kitDir "scripts")) {
    Remove-Item -LiteralPath (Join-Path $kitDir "scripts") -Recurse -Force
}
if (Test-Path -LiteralPath (Join-Path $kitDir "templates")) {
    Remove-Item -LiteralPath (Join-Path $kitDir "templates") -Recurse -Force
}

Copy-Item -LiteralPath (Join-Path $packageRoot "scripts") -Destination (Join-Path $kitDir "scripts") -Recurse -Force
Copy-Item -LiteralPath (Join-Path $packageRoot "templates") -Destination (Join-Path $kitDir "templates") -Recurse -Force

python (Join-Path $kitDir "scripts\install_control_docs.py") --target $targetRoot --variant $Variant

Write-Host "Adaptador Antigravity instalado en: $kitDir"
Write-Host "Regla instalada en: $(Join-Path $rulesDir 'control-trazabilidad-proyecto.md')"

