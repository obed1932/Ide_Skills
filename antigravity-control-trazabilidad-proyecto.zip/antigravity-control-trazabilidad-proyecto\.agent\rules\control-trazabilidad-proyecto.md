# Regla: Control y Trazabilidad de Proyecto

Activa esta regla cuando el usuario pida control documental, trazabilidad, historial de cambios, bitacora IA, auditoria del repo, fuente de verdad o estructura de seguimiento para un proyecto.

## Flujo

1. Identifica la raiz real del repo destino.
2. Elige variante:
   - `minimal`: proyecto pequeno.
   - `base`: proyecto estandar.
   - `enterprise`: auditoria, riesgos, incidentes, compliance.
   - `fullstack-ia`: backend, frontend, Docker, migraciones, scripts o trabajo frecuente con IA.
3. Ejecuta:

```powershell
python scripts/install_control_docs.py --target "RUTA_DEL_REPO" --variant fullstack-ia
```

4. Si el instalador reporta archivos omitidos, revisalos antes de proponer `--force`.
5. Completa primero `CONTROL_PROYECTO_AUDITADO.md` con hechos comprobados del repo.

## Reglas estrictas

- No inventar estado del proyecto.
- No borrar ni reemplazar documentos existentes sin permiso.
- No registrar secretos ni credenciales.
- Diferenciar hallazgos confirmados de pendientes por revisar.

