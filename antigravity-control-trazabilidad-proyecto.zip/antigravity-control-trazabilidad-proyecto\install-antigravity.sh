#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-}"
VARIANT="${2:-fullstack-ia}"

if [ -z "$TARGET" ]; then
  echo "Uso: ./install-antigravity.sh /ruta/del/repo [variant]"
  exit 1
fi

PACKAGE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="$(cd "$TARGET" && pwd)"
AGENT_DIR="$TARGET_ROOT/.agent"
RULES_DIR="$AGENT_DIR/rules"
KIT_DIR="$AGENT_DIR/control-trazabilidad-proyecto"

mkdir -p "$RULES_DIR" "$KIT_DIR"

cp "$PACKAGE_ROOT/.agent/rules/control-trazabilidad-proyecto.md" "$RULES_DIR/control-trazabilidad-proyecto.md"
cp "$PACKAGE_ROOT/AGENTS.md" "$KIT_DIR/AGENTS.md"
cp "$PACKAGE_ROOT/GEMINI.md" "$KIT_DIR/GEMINI.md"
cp "$PACKAGE_ROOT/README_ANTIGRAVITY.md" "$KIT_DIR/README_ANTIGRAVITY.md"

rm -rf "$KIT_DIR/scripts" "$KIT_DIR/templates"
cp -R "$PACKAGE_ROOT/scripts" "$KIT_DIR/scripts"
cp -R "$PACKAGE_ROOT/templates" "$KIT_DIR/templates"

python "$KIT_DIR/scripts/install_control_docs.py" --target "$TARGET_ROOT" --variant "$VARIANT"

echo "Adaptador Antigravity instalado en: $KIT_DIR"
echo "Regla instalada en: $RULES_DIR/control-trazabilidad-proyecto.md"

