# Instrucciones para Agentes

Usa las reglas de `AGENTS.md` y `.agent/rules/control-trazabilidad-proyecto.md`.

Este paquete instala archivos Markdown de control, trazabilidad, historial, bitacora IA, decisiones, inventario y deuda tecnica en repositorios de software.

Comando recomendado:

```powershell
python scripts/install_control_docs.py --target "RUTA_DEL_REPO" --variant fullstack-ia
```

