# Control Trazabilidad Proyecto para Antigravity

Carpeta portable convertida desde la skill de Codex `control-trazabilidad-proyecto`.

## Contenido

- `AGENTS.md`: instrucciones principales para el agente.
- `GEMINI.md`: archivo de compatibilidad para agentes que leen instrucciones tipo Gemini.
- `.agent/rules/control-trazabilidad-proyecto.md`: regla especifica del kit.
- `scripts/install_control_docs.py`: instalador de documentos Markdown.
- `templates/`: variantes disponibles.
- `ORIGINAL_CODEX_SKILL.md`: skill original conservada como referencia.

## Uso directo

Desde esta carpeta:

```powershell
python scripts/install_control_docs.py --target "C:\ruta\del\repo" --variant fullstack-ia
```

## Uso dentro de un repo Antigravity

Copia esta carpeta completa dentro del repo, o ejecuta:

```powershell
.\install-antigravity.ps1 -Target "C:\ruta\del\repo"
```

Luego pide al agente:

```txt
Aplica control-trazabilidad-proyecto fullstack-ia en este repo.
```

## Variantes

- `minimal`
- `base`
- `enterprise`
- `fullstack-ia`

