$ErrorActionPreference = "Stop"

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $packageRoot ".claude\skills\control-trazabilidad-proyecto"
$target = Join-Path $HOME ".claude\skills\control-trazabilidad-proyecto"

New-Item -ItemType Directory -Force (Split-Path -Parent $target) | Out-Null
Copy-Item -Recurse -Force $source $target

Write-Host "Skill instalada en: $target"
Write-Host "Reinicia Claude Code si ya estaba abierto."
