## Skill portable para Claude Code

Este paquete instala la skill `control-trazabilidad-proyecto` como skill global de Claude Code.

Estructura incluida:

- `.claude/skills/control-trazabilidad-proyecto/`
- `install-global.ps1`
- `install-global.sh`

Instalacion en otra PC:

1. Descomprime este ZIP en cualquier carpeta temporal.
2. Ejecuta `install-global.ps1` en Windows o `install-global.sh` en macOS/Linux.
3. Abre o reinicia Claude Code.
4. Usa la skill por nombre o de forma automatica cuando el caso aplique.

Ruta global esperada en la PC destino:

- `~/.claude/skills/control-trazabilidad-proyecto/SKILL.md`

Notas:

- Si la carpeta `~/.claude/skills/` no existia antes de abrir Claude Code, reinicia la sesion para que empiece a vigilarla.
- Este paquete es portable: puedes mover el ZIP por USB, nube o red local y luego instalarlo sin depender de este repositorio.
